﻿using System.ComponentModel.DataAnnotations;

namespace JanBatchCodeFirstApproachImpl.Models
{
    public class Emp
    {
        [Key]
        public int eid { get; set; }
        public string ename { get; set; }
        public string email { get; set; }

        public double salary { get; set; }
    }
}
